//
//  ChatController.h
//  微信
//
//  Created by Think_lion on 15/6/18.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XMPPJID;

@interface ChatController : UIViewController

@property (nonatomic,strong) XMPPJID *jid;
//聊天用户的 头像
@property (nonatomic,weak) UIImage *photo;

@end
