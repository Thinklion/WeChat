//
//  HMEmotionGridView.h
//  黑马微博
//
//  Created by apple on 14-7-17.
//  Copyright (c) 2014年 heima. All rights reserved.
//  一个HMEmotionGridView展示一页的表情

#import <UIKit/UIKit.h>

@interface HMEmotionGridView : UIView
/** 需要展示的所有表情 */
@property (nonatomic, strong) NSArray *emotions;
@end
