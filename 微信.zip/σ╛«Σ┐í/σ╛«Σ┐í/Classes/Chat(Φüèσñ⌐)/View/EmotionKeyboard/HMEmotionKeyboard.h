//
//  HMEmotionKeyboard.h
//  黑马微博
//
//  Created by apple on 14-7-15.
//  Copyright (c) 2014年 heima. All rights reserved.
//  表情键盘

#import <UIKit/UIKit.h>

@interface HMEmotionKeyboard : UIView
+ (instancetype)keyboard;
@end
