//
//  ChatViewShow.m
//  微信
//
//  Created by Think_lion on 15/6/21.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "ChatViewShow.h"
#import "MessageFrameModel.h"
#import "MessageModel.h"

@interface ChatViewShow ()
//时间
@property (nonatomic,weak) UILabel *timeLabel;
//正文内容
@property (nonatomic,weak) UIButton *contentBtn;
//头像
@property (nonatomic,weak) UIImageView *headImage;
//
@end

@implementation ChatViewShow

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self){
        //1.添加子控件
        [self setupChildView];
        
       
    }
    return self;
}
#pragma mark 添加子控件
-(void)setupChildView
{
   //1.时间
    UILabel *timeLabel=[[UILabel alloc]init];
    timeLabel.textColor=[UIColor lightGrayColor];
    timeLabel.font=MyFont(15);
    timeLabel.textAlignment=NSTextAlignmentCenter;
    timeLabel.textColor=[UIColor lightGrayColor];
    [self addSubview:timeLabel];
    self.timeLabel=timeLabel;
    //2.正文内容
    UIButton *contentBtn=[[UIButton alloc]init];
    [contentBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    contentBtn.titleLabel.font=MyFont(15);
    contentBtn.titleLabel.numberOfLines=0;  //多行显示
    contentBtn.contentEdgeInsets=UIEdgeInsetsMake(10, 20, 20, 20);
    
    
    [self addSubview:contentBtn];
    self.contentBtn=contentBtn;
    //3.头像
    UIImageView *headImage=[[UIImageView alloc]init];
    [self addSubview:headImage];
    self.headImage=headImage;
    
}

//传递模型
-(void)setFrameModel:(MessageFrameModel *)frameModel
{
    _frameModel=frameModel;
    //设置自己的frame
    self.frame=frameModel.chatF;
  
    //1.时间的frame
    self.timeLabel.frame=frameModel.timeF;
    self.timeLabel.text=frameModel.messageModel.time;
    //2头像的frame
    if(frameModel.messageModel.isCurrentUser){  //如果是自己
        UIImage *head=frameModel.messageModel.headImage?[UIImage imageWithData:frameModel.messageModel.headImage]:[UIImage imageNamed:@"DefaultCompanyHead"];
        self.headImage.image=head;
    }else{  //如果是聊天的用户
       self.headImage.image=frameModel.messageModel.otherPhoto?frameModel.messageModel.otherPhoto:[UIImage imageNamed:@"DefaultHead"];
    }
   
    self.headImage.frame=frameModel.headF;
    //3.内容的frame
    [self.contentBtn setAttributedTitle:frameModel.messageModel.attributedBody forState:UIControlStateNormal];
   
   
    self.contentBtn.frame=frameModel.contentF;
    //4.设置聊天的背景图片
    if(frameModel.messageModel.isCurrentUser){  //如果是自己
        [self.contentBtn setBackgroundImage:[UIImage resizedImage:@"SenderTextNodeBkg"] forState:UIControlStateNormal];
    }else {  //别人的
         [self.contentBtn setBackgroundImage:[UIImage resizedImage:@"ReceiverAppNodeBkg"] forState:UIControlStateNormal];
    }
    
}


@end
