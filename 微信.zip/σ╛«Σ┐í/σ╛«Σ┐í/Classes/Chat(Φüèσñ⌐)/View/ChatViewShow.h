//
//  ChatViewShow.h
//  微信
//
//  Created by Think_lion on 15/6/21.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MessageFrameModel;

@interface ChatViewShow : UIView

@property (nonatomic,strong) MessageFrameModel *frameModel;


@end
