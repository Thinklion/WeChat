//
//  UserOperation.m
//  微信
//
//  Created by Think_lion on 15/6/16.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "UserOperation.h"
#import "MyTabBarController.h"
#import "LoginViewController.h"
#import "MyNavController.h"

@implementation UserOperation

SingletonM(user);

-(void)setUname:(NSString *)uname
{
    //_uname=[uname copy];
    [MyDefaults setObject:uname forKey:@"username"];
    
    [MyDefaults synchronize];
}
-(void)setPassword:(NSString *)password
{
   // _password=[password copy];
    [MyDefaults setObject:password forKey:@"password"];
    [MyDefaults synchronize];
}
-(void)setLoginStatus:(BOOL)loginStatus
{
    [MyDefaults setBool:loginStatus forKey:@"loginStatus"];
    [MyDefaults synchronize];
}

-(NSString *)uname
{
   NSString *name= [MyDefaults objectForKey:@"username"];
    return name;
}

-(NSString *)password
{
    NSString *pass=[MyDefaults objectForKey:@"password"];
    return pass;
}
-(BOOL)loginStatus
{
    BOOL b=[MyDefaults boolForKey:@"loginStatus"];
    return b;
}

#pragma mark 通过登录状态
+(void)loginByStatus
{
    UserOperation *user=[UserOperation shareduser];
    if(user.loginStatus){
        //登录
        XmppTools *xmpp=[XmppTools sharedxmpp];
        [xmpp login:nil];
        
        MyTabBarController *tab=[[MyTabBarController alloc]init];
        [UIApplication sharedApplication].keyWindow.rootViewController=tab;
       
       
        
    }else{
        LoginViewController *login=[[LoginViewController alloc]init];
        MyNavController *nav=[[MyNavController alloc]initWithRootViewController:login];
        [UIApplication sharedApplication].keyWindow.rootViewController=nav;

    }
}


@end
