//
//  UserOperation.h
//  微信
//
//  Created by Think_lion on 15/6/16.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UserOperation.h"

@interface UserOperation : NSObject
SingletonH(user);
//把用户名和密码保存到沙河
@property (nonatomic,copy)NSString *uname;
@property (nonatomic,copy)NSString *password;
//登录的状态
@property (nonatomic,assign) BOOL loginStatus;

+(void)loginByStatus;

@end
