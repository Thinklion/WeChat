//
//  FmbdMessage.h
//  微信
//
//  Created by Think_lion on 15/7/5.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FmbdMessage : NSObject

+(void)deleteChatData:(NSString*)jid;

@end
