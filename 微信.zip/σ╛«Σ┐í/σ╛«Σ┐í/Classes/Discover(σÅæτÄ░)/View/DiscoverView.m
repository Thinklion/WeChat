//
//  DiscoverView.m
//  微信
//
//  Created by Think_lion on 15/6/26.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "DiscoverView.h"
#import "TableCellitemModel.h"

#define headWidth 30
#define headHeight headWidth
#define marginLeft 10

@interface DiscoverView ()
@property (nonatomic,weak) UIImageView *head;
@property (nonatomic,weak) UILabel *name;
@property (nonatomic,weak) UILabel *detailTitle;
@property (nonatomic,weak) UIButton *arrow;

@end

@implementation DiscoverView

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self){
      //  self.backgroundColor=[UIColor redColor];
        //1.添加 视图
        [self addDiscoverView];
    }
    return self;
}

-(void)addDiscoverView
{
  
    //1.添加头像
    UIImageView *head=[[UIImageView alloc]init];
    CGFloat headY=7;
    head.frame=CGRectMake(marginLeft, headY, headWidth, headHeight);
    [self addSubview:head];
    self.head=head;
    //2.添加用户名
    UILabel *name=[[UILabel alloc]init];
    name.font=MyFont(17);
    CGFloat nameX=CGRectGetMaxX(head.frame)+marginLeft*2;
    name.textColor=[UIColor blackColor];
    name.frame=CGRectMake(nameX, 7, 200, headHeight);
    [self addSubview:name];
    self.name=name;
    //3.添加详细标题
    UILabel *detailTitle=[[UILabel alloc]init];
    detailTitle.font=MyFont(15);
    detailTitle.textColor=[UIColor lightGrayColor];
    [self addSubview:detailTitle];
    detailTitle.hidden=YES;
    self.detailTitle=detailTitle;
    
    //4.添加箭头
    UIButton *arrow=[[UIButton alloc]init];
  
    CGFloat arrowW=20;
    CGFloat arrowH=arrowW;
    CGFloat arrowY=(self.height-arrowH)*0.5;
    CGFloat arrowX=ScreenWidth-arrowW-marginLeft;
    arrow.frame=CGRectMake(arrowX, arrowY, arrowW, arrowH);
    arrow.userInteractionEnabled=NO;
    [arrow setImage:[UIImage resizedImage:@"pay_arrowright"] forState:UIControlStateNormal];
    [self addSubview:arrow];
    self.arrow=arrow;
    
}
//设置模型
-(void)setItem:(TableCellitemModel *)item
{
    _item=item;
    //1.设置头像
    if(item.image){
          //fts_default_headimage
        self.head.layer.cornerRadius=5;
        self.head.layer.borderWidth=0.5;
        self.head.layer.borderColor=[UIColor grayColor].CGColor;
        self.head.image=[UIImage imageWithData:item.image];
    }else{
        self.head.image=[UIImage imageNamed:item.icon];
    }
    
    //2.设置title
    self.name.text=item.title;
    //3.设置详细标题
    if(item.detailTitle){
        self.detailTitle.hidden=NO;
        CGSize detailS=[item.detailTitle sizeWithAttributes:@{NSFontAttributeName:MyFont(15)}];
        CGFloat detailW=detailS.width;
        CGFloat detailH=detailS.height;
        CGFloat detailY=(self.height-detailH)*0.5;
        CGFloat detailX=ScreenWidth-detailW-self.arrow.width-marginLeft;
        self.detailTitle.frame=CGRectMake(detailX, detailY, detailW, detailH);
        self.detailTitle.text=item.detailTitle;
    }
   
}

@end
