//
//  DiscoverCell.m
//  微信
//
//  Created by Think_lion on 15/6/26.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "DiscoverCell.h"
#import "DiscoverView.h"
#import "TableCellitemModel.h"

@interface DiscoverCell ()
@property (nonatomic,weak) DiscoverView *dView;
@end

@implementation DiscoverCell


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self){
        //.添加子视图
        [self addView];
    }
    
    return self;
}
-(void)addView
{
    DiscoverView *dView=[[DiscoverView alloc]initWithFrame:self.bounds];
    self.dView=dView;
    [self.contentView addSubview:dView];
}
#pragma mark 初始化单元格
+(instancetype)cellWithTableView:(UITableView *)tableView indentifier:(NSString *)indentifier
{
    DiscoverCell *cell=[tableView dequeueReusableCellWithIdentifier:indentifier];
    if(cell==nil){
        cell=[[DiscoverCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentifier];
    }
    
    return cell;
}

//设置模型
-(void)setItem:(TableCellitemModel *)item
{
    _item=item;
    self.dView.item=item;
   
}

@end
