//
//  TableCellitemModel.m
//  微信
//
//  Created by Think_lion on 15/6/26.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "TableCellitemModel.h"

@implementation TableCellitemModel

+(instancetype)itemWithIcon:(NSString *)icon title:(NSString *)title detailTitle:(NSString *)detailTitle vcClass:(Class)vcClass
{
    TableCellitemModel *item=[[TableCellitemModel alloc]init];
    item.title=title;
    item.detailTitle=detailTitle;
    item.icon=icon;
    item.vcClass=vcClass;
    return item;
}

@end
