//
//  TableGroupModel.h
//  微信
//
//  Created by Think_lion on 15/6/26.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TableGroupModel : NSObject

@property (nonatomic,copy) NSString *header;
@property (nonatomic,copy) NSString *footer;
@property (nonatomic,strong) NSArray *items; //里面存贮的是tableCellitem模型

@end
