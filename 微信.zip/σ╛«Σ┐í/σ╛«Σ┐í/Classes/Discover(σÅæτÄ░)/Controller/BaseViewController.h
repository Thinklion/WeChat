//
//  BaseViewController.h
//  微信
//
//  Created by Think_lion on 15/6/26.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UITableViewController

@property (nonatomic,strong) NSMutableArray *datas;


@end
