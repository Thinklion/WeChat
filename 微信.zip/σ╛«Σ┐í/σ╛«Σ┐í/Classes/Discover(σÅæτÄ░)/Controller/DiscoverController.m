//
//  DiscoverController.m
//  微信
//
//  Created by Think_lion on 15-6-14.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "DiscoverController.h"
#import "TableCellitemModel.h"
#import "TableGroupModel.h"

@interface DiscoverController ()

@end

@implementation DiscoverController

- (void)viewDidLoad {
    [super viewDidLoad];
    //1.第一组
    TableCellitemModel *friend=[TableCellitemModel itemWithIcon:@"AlbumReflashIcon" title:@"朋友圈" detailTitle:nil vcClass:nil];
   
  //  friend.option=^{};
    TableGroupModel *group1=[[TableGroupModel alloc]init];
    group1.items=@[friend];
    [self.datas addObject:group1];
    
    //2.第二组
    TableCellitemModel *clear=[TableCellitemModel itemWithIcon:@"ff_IconQRCode" title:@"扫一扫" detailTitle:nil vcClass:nil];
    TableCellitemModel *shake=[TableCellitemModel itemWithIcon:@"ff_IconShake" title:@"摇一摇" detailTitle:nil vcClass:nil];
    TableGroupModel *group2=[[TableGroupModel alloc]init];
    group2.items=@[clear,shake];
    [self.datas addObject:group2];
    //3.第三组
    TableCellitemModel *closePeople=[TableCellitemModel itemWithIcon:@"ff_IconLocationService" title:@"附近的人" detailTitle:nil vcClass:nil];
    TableCellitemModel *bottle=[TableCellitemModel itemWithIcon:@"ff_IconBottle" title:@"漂流瓶" detailTitle:nil vcClass:nil];
    TableGroupModel *group3=[[TableGroupModel alloc]init];
    group3.items=@[closePeople,bottle];
    [self.datas addObject:group3];
    //4.第四组
    TableCellitemModel *shop=[TableCellitemModel itemWithIcon:@"CreditCard_ShoppingBag" title:@"购物" detailTitle:@"淘宝商城" vcClass:nil];
    TableCellitemModel *game=[TableCellitemModel itemWithIcon:@"MoreGame" title:@"游戏" detailTitle:nil vcClass:nil];
    TableGroupModel *group4=[[TableGroupModel alloc]init];
    group4.items=@[shop,game];
    [self.datas addObject:group4];
}



@end
