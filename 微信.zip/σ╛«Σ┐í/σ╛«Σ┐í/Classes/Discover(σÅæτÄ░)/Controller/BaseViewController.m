//
//  BaseViewController.m
//  微信
//
//  Created by Think_lion on 15/6/26.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "BaseViewController.h"
#import "TableGroupModel.h"
#import "TableCellitemModel.h"
#import "DiscoverCell.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

-(instancetype)init
{
    self=[super initWithStyle:UITableViewStyleGrouped];
    if(self){
        
    }
    return self;
}

-(NSMutableArray *)datas
{
    if(!_datas){
        _datas=[NSMutableArray array];
    }
    return _datas;
}

- (void)viewDidLoad {
    [super viewDidLoad];
     self.tableView.contentInset=UIEdgeInsetsMake(15, 0, 5, 0);
    self.tableView.backgroundColor=WColor(236, 236, 244);
}


#pragma mark 返回多少行
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return self.datas.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    TableGroupModel *group=self.datas[section];

    return group.items.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  

    DiscoverCell *cell=[DiscoverCell cellWithTableView:tableView indentifier:@"discoverCell"];
    TableGroupModel *group=self.datas[indexPath.section];
    cell.item=group.items[indexPath.row];
    
    return cell;
}

#pragma mark 设置组的标题
-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    TableGroupModel *group=self.datas[section];
    return group.header;
}
#pragma mark 设置组的footer标题
-(NSString*)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
{
    TableGroupModel *group=self.datas[section];
    return group.footer;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 2;
}

#pragma mark 单元格点击的事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    TableGroupModel *group=self.datas[indexPath.section];
    TableCellitemModel *item=group.items[indexPath.row];
    if(item.option){
        item.option(); //调用block
    }else{
        if(item.vcClass==nil) return;
       //跳转
        [self.navigationController pushViewController:[[item.vcClass alloc]init] animated:YES];
    }
}


@end
