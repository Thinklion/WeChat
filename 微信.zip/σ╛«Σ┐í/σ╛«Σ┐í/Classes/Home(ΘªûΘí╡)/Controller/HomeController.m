//
//  HomeController.m
//  微信
//
//  Created by Think_lion on 15-6-14.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "HomeController.h"
#import "UIBarButtonItem+CH.h"
#import "HomeViewCell.h"
#import "HomeModel.h"
#import "FmdbTool.h"
#import "ChatController.h"
#import "FmbdMessage.h"


@interface HomeController ()
//存放聊天最后一段信息的数组
@property(nonatomic,strong) NSMutableArray *chatData;

@property (nonatomic,assign)int messageCount; //未读的消息总数

@end

@implementation HomeController


-(instancetype)init
{
    self=[super initWithStyle:UITableViewStyleGrouped];
    if(self){
    }
    return self;
}
-(NSMutableArray *)chatData
{
    if(!_chatData){
        _chatData=[NSMutableArray array];
    }
    return _chatData;
}

- (void)viewDidLoad {
    [super viewDidLoad];
   //1.添加搜索栏
    [self setupSearchBar];
    //2.从本地数据库中读取正在聊天的好友数据
    [self readChatData];
    //3.添加导航栏右侧的按钮
    [self setupRightButtun];
    
    
    //监听消息来得通知
    [Mynotification addObserver:self selector:@selector(messageCome:) name:SendMsgName object:nil];
    //监听删除好友时发出的通知
    [Mynotification addObserver:self selector:@selector(deleteFriend:) name:DeleteFriend object:nil];
}

#pragma mark   从本地数据库中读取正在聊天的好友数据
-(void)readChatData
{
    
    NSArray *arr=[FmdbTool selectAllData];
    self.chatData=[arr mutableCopy];
    //如果有未读消息的话 在标签栏下面显示未读消息
    for(HomeModel *model in arr){
        if(model.badgeValue.length>0 && ![model.badgeValue isEqualToString:@""]){
            int currentV=[model.badgeValue intValue];
            self.messageCount+=currentV;
        }
    }
    //如果消息数大于0
    if(self.messageCount>0){
        //如果消息总数大于99
        if(self.messageCount>=99){
            self.tabBarItem.badgeValue=@"99+";
        }else{
            self.tabBarItem.badgeValue=[NSString stringWithFormat:@"%d",self.messageCount];
        }
        
    }
}

#pragma mark 有消息来的时候
-(void)messageCome:(NSNotification*)note
{
    NSDictionary *dict=[note object];
    NSLog(@"%@",dict[@"user"]);
    //设置未读消息总数消息 ([dict[@"user"]如果是正在和我聊天的用户才设置badgeValue)
    if([dict[@"user"] isEqualToString:@"other"]){
        dispatch_async(dispatch_get_main_queue(), ^{
            self.messageCount++;
            if(self.messageCount>=99){
                self.tabBarItem.badgeValue=@"99+";
            }else{
                self.tabBarItem.badgeValue=[NSString stringWithFormat:@"%d",self.messageCount];
            }
            
        });
    }
  
   
    
    //修改信息  在主线程中执行（速度快）
    dispatch_async(dispatch_get_main_queue(), ^{
        [self updateMessage:note];
    });
    
}
-(void)updateMessage:(NSNotification*)note
{
    NSDictionary *dict=[note object];
    NSString *uname=[dict objectForKey:@"uname"]; //获得用户名
    NSString *body=[dict objectForKey:@"body"];
    XMPPJID *jid =[dict objectForKey:@"jid"];
    NSString *time=[dict objectForKey:@"time"];
    NSString *user=[dict objectForKey:@"user"];
    
    
    //如果用户在本地数据库中已存在 就直接更新聊天数据
    if([FmdbTool selectUname:uname]){
       // NSLog(@"更新");
        //回到主线程  执行这些方法
            //修改模型数据
            for(HomeModel *model in self.chatData){
                //如果是同一个用户名
                
                if([model.uname isEqualToString:uname]){
                    model.body=body;
                    model.time=time;
                    //如果是正在和我聊天的用户 才设置badgeValue
                    if([user isEqualToString:@"other"]){
                        int currentV=[model.badgeValue intValue]+1;
                        model.badgeValue=[NSString stringWithFormat:@"%d",currentV];
                    }
                    
                    
                    [self.tableView reloadData];
                    
                    //更新数据库里面的值
                    [FmdbTool updateWithName:uname detailName:body time:time badge:model.badgeValue];
                }
                
            }
            
        
    }else{  //没有的话  添加数据
        HomeModel *homeModel=[[HomeModel alloc]init];
        homeModel.uname=uname;
        homeModel.body=body;
        homeModel.jid=jid;
        homeModel.time=time;
        if([user isEqualToString:@"other"]){
            homeModel.badgeValue=@"1";
        }else{
            homeModel.badgeValue=nil;
        }
        
        
        [self.chatData addObject:homeModel];
        //重新加载标示图
        [self.tableView reloadData];
        
        [FmdbTool addHead:nil uname:uname detailName:body time:time badge:homeModel.badgeValue xmppjid:jid];
        //NSLog(@"添加");
        
    }

}
#pragma mark 删除好友时同步的聊天数据
-(void)deleteFriend:(NSNotification*)note
{
    NSString *uname=[note object];
    //初始化模型的索引
    NSInteger index=0;
    for(HomeModel *model in self.chatData){
        if([model.uname isEqualToString:uname]){
            NSLog(@"%@     %@",model.uname, uname);
            [_chatData removeObjectAtIndex:index];
            //从本地数据库清除
            [FmdbTool deleteWithName:uname];
            //重新刷新标示图
            [self.tableView reloadData];
        }
        index++;
    }
    
}
#pragma mark 添加搜索栏
-(void)setupSearchBar
{
    UISearchBar *search=[[UISearchBar alloc]init];
    
    search.frame=CGRectMake(10, 5, ScreenWidth-20, 25);
    search.barStyle=UIBarStyleDefault;
    search.backgroundColor=[UIColor whiteColor];
  
    //实例化一个搜索栏
    //取消首字母吧大写
    search.autocapitalizationType=UITextAutocapitalizationTypeNone;
    search.autocorrectionType=UITextAutocorrectionTypeNo;
    //代理
    search.placeholder=@"搜索";
    search.layer.borderWidth=0;
    
    UIView *searchV=[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 35)];
    searchV.backgroundColor=WColorAlpha(189, 189, 195, 0.7);
    [searchV addSubview:search];
   // search.delegate=self;
  
    
    self.tableView.tableHeaderView=searchV;
    
    
    
}
#pragma mark
-(void)setupRightButtun
{
    self.navigationItem.rightBarButtonItem=[UIBarButtonItem itemWithIcon:@"barbuttonicon_add" highIcon:nil target:self action:@selector(rightClick)];

}
-(void)rightClick
{
    NSLog(@"sss");
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.chatData.count;
}
#pragma mark 单元格的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    return 60;
}
#pragma mark 设置单元格
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    HomeViewCell *cell=[HomeViewCell cellWithTableView:tableView cellWithIdentifier:@"homeCell"];
 
    HomeModel *model=self.chatData[indexPath.row];
    //传递模型
    cell.homeModel=model;
    return cell;
}
#pragma mark 单元格的点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //隐藏对象的小红点
    HomeModel *homeModel=self.chatData[indexPath.row];
    //标签栏数字按钮减少
    self.messageCount=self.messageCount-[homeModel.badgeValue intValue];
    //如果消息数大于0
    if(self.messageCount>0){
        self.tabBarItem.badgeValue=[NSString stringWithFormat:@"%d",self.messageCount];
    }else{
        self.tabBarItem.badgeValue=nil;
    }
    //清除模型中得数据
    homeModel.badgeValue=nil;
    //重新刷新表视图
    [self reloadData];
    
    [FmdbTool clearRedPointwithName:homeModel.uname];//清除数据库中的数据
    ChatController *chat=[[ChatController alloc]init];
    chat.title=homeModel.jid.user;
    chat.jid=homeModel.jid;
    [self.navigationController pushViewController:chat animated:YES];
}

-(void)reloadData
{
    
    [self.tableView reloadData];
}
#pragma mark 滑动删除单元格
-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}
#pragma mark 改变删除单元格按钮的文字
-(NSString*)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}
#pragma mark 单元格删除的点击事件
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    HomeModel *homeModel=self.chatData[indexPath.row];
    NSString *name=homeModel.uname;
    //当点击删除按钮的时候执行
    if(editingStyle==UITableViewCellEditingStyleDelete){
        //删除对应的红色提醒按钮
        int badge=[homeModel.badgeValue intValue];
        if(badge>0){
            _messageCount=_messageCount-badge;
            self.tabBarItem.badgeValue=[NSString stringWithFormat:@"%d",_messageCount];
        }
        
        //删除该好友所有的聊天数据
        NSLog(@"%@",homeModel.jid);
        [FmbdMessage deleteChatData:[NSString stringWithFormat:@"%@@ios268",homeModel.uname]];
//        
        NSInteger count=indexPath.row;
        //删除模型
        [self.chatData removeObjectAtIndex:count];
        [self.tableView reloadData];
        //删除首页的聊天数据模型
        //删除数据库中的好友的数据
        [FmdbTool deleteWithName:name];
        
       
    }
}

//滚动视图停止编辑
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}
-(void)dealloc
{
    [Mynotification removeObserver:self];
    NSLog(@"销毁了");
}



@end
