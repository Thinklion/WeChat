//
//  HomeConstomView.h
//  微信
//
//  Created by Think_lion on 15/6/29.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HomeModel;

@interface HomeConstomView : UIView

@property (nonatomic,strong) HomeModel *homeModel;

@end
