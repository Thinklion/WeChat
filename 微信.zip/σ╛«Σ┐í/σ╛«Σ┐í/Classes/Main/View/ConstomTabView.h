//
//  ConstomTabView.h
//  微信
//
//  Created by Think_lion on 15-6-14.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ConstomTabView;
//协议
@protocol ConstomTabViewDelegate <NSObject>

@optional
-(void)tabBar:(ConstomTabView *)tabBar didSelectedButtonFrom:(NSInteger)from to:(NSInteger)to;

@end

@interface ConstomTabView : UIView

-(void)addTabBarButtonItem:(UITabBarItem *)item;

@property (nonatomic,weak) id<ConstomTabViewDelegate>delegate;

@end
