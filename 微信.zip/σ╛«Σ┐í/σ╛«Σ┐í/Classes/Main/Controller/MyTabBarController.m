//
//  MyTabBarController.m
//  微信
//
//  Created by Think_lion on 15-6-14.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "MyTabBarController.h"
#import "MyNavController.h"
#import "HomeController.h"
#import "ContacterController.h"
#import "DiscoverController.h"
#import "MeController.h"
#import "ConstomTabView.h"

@interface MyTabBarController ()<ConstomTabViewDelegate>
//自定义的标签栏
@property (nonatomic,weak) ConstomTabView *constomTabbar;

@property (nonatomic,strong) HomeController  *home;
@property (nonatomic,strong) ContacterController *contacter;
@property (nonatomic,strong) DiscoverController *discover;
@property (nonatomic,strong) MeController *me;

@end

@implementation MyTabBarController

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //这样才会显示tabBar上面的按钮
    //NSLog(@"%@",self.tabBar.subviews);
    
    for(UIView *child in self.tabBar.subviews){
        //NSLog(@"%@",child.superclass);   输出 UIControl
        if([child isKindOfClass:[UIControl class]]){
            [child removeFromSuperview];  //从父类视图中移除
        }
    }
    
}





- (void)viewDidLoad {
    [super viewDidLoad];
    //1.添加自定义的标签栏
    [self setupTabbar];
    //2.添加子控制器
    [self setupChilControllers];
}

#pragma  mark 初始化标签栏的方法
-(void)setupTabbar{
    ConstomTabView *constomTabbar=[[ConstomTabView alloc]init];
  
    constomTabbar.delegate=self;  //实现代理

    constomTabbar.frame=self.tabBar.bounds;
    
    [self.tabBar addSubview:constomTabbar];
    //给视图TabBar赋值  就是创建标签栏视图
    self.constomTabbar=constomTabbar;
}
#pragma mark 实现自定义标签试图的代理方法
-(void)tabBar:(ConstomTabView *)tabBar didSelectedButtonFrom:(NSInteger)from to:(NSInteger)to
{
  //  NSLog(@"%zd   to%zd",from,to);
    self.selectedIndex=to;
}
#pragma mark 添加自控制器
-(void)setupChilControllers
{
    //1.首页
    HomeController *home=[[HomeController alloc]init];
    self.home=home;
   // home.tabBarItem.badgeValue=@"9";
    [self setupChildViewController:home title:@"微信" imageName:@"tabbar_mainframe" selectedImageName:@"tabbar_mainframeHL"];
    //2.通讯录
    ContacterController *contacter=[[ContacterController alloc]init];
    self.contacter=contacter;
    //contacter.tabBarItem.badgeValue=@"78";
    [self setupChildViewController:contacter title:@"通讯录" imageName:@"tabbar_contacts" selectedImageName:@"tabbar_contactsHL"];
    //3.发现
    DiscoverController *discover=[[DiscoverController alloc]init];
    self.discover=discover;
    //discover.tabBarItem.badgeValue=@"1000";
     [self setupChildViewController:discover title:@"发现" imageName:@"tabbar_discover" selectedImageName:@"tabbar_discoverHL"];
   //4.我
    MeController *me=[[MeController alloc]init];
    //me.tabBarItem.badgeValue=@"8";
    self.me=me;
     [self setupChildViewController:me title:@"我" imageName:@"tabbar_me" selectedImageName:@"tabbar_meHL"];
    

}
#pragma mark 初始化视图控制器的方法
-(void)setupChildViewController:(UIViewController*)childVc title:(NSString *)title imageName:(NSString*)imageName selectedImageName:(NSString*)selectedImageName
{
    childVc.title=title;
    childVc.tabBarItem.image=[UIImage imageNamed:imageName];  //正常图片
    childVc.tabBarItem.selectedImage=[UIImage imageNamed:selectedImageName];//选中的图片
    MyNavController *nav=[[MyNavController alloc]initWithRootViewController:childVc];
    //添加到标签栏控制器里面
    [self addChildViewController:nav];
    //把UIBarItem属性传递给自定义的view
    [self.constomTabbar addTabBarButtonItem:childVc.tabBarItem];
}



//返回白色的状态栏
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

@end
