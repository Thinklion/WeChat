//
//  MeController.m
//  微信
//
//  Created by Think_lion on 15-6-14.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "MeController.h"
#import "TableCellitemModel.h"
#import "TableGroupModel.h"
#import "ProfileViewController.h"
#import "SettingViewController.h"

@interface MeController ()
@property (nonatomic,strong)  TableCellitemModel *userSetting;
@end

@implementation MeController


#warning 继承了Discover(发现)里面的BaseViewController根控制器
- (void)viewDidLoad {
    [super viewDidLoad];
    //[self addRunloop];
    //1.获得修改头像图片过来的通知
    [Mynotification addObserver:self selector:@selector(changeHead:) name:@"changeHeadIcon" object:nil];
    XmppTools *app=[XmppTools sharedxmpp];
    XMPPvCardTemp *temp=app.vCard.myvCardTemp;
  
    //1.第一个组
    TableGroupModel *group1=[[TableGroupModel alloc]init];
    TableCellitemModel *userSetting=[TableCellitemModel itemWithIcon:@"fts_default_headimage" title:@"用户" detailTitle:@"" vcClass:[ProfileViewController class]];
   //获得用户的头像
    userSetting.image=temp.photo;
    group1.items=@[userSetting];
    [self.datas addObject:group1];
    self.userSetting=userSetting;
    //2.第二个组
    TableGroupModel *group2=[[TableGroupModel alloc]init];
    TableCellitemModel *photos=[TableCellitemModel itemWithIcon:@"MoreMyAlbum" title:@"相册" detailTitle:@"" vcClass:nil];
    TableCellitemModel *favar=[TableCellitemModel itemWithIcon:@"MoreMyFavorites" title:@"收藏" detailTitle:@"" vcClass:nil];
    TableCellitemModel *money=[TableCellitemModel itemWithIcon:@"MoreMyBankCard" title:@"钱包" detailTitle:@"" vcClass:nil];
    group2.items=@[photos,favar,money];
    [self.datas addObject:group2];
    
    //3.第三个组
    TableGroupModel *group3=[[TableGroupModel alloc]init];
    TableCellitemModel *face=[TableCellitemModel itemWithIcon:@"MoreExpressionShops" title:@"表情" detailTitle:@"" vcClass:nil];
    group3.items=@[face];
    [self.datas addObject:group3];
    //4.第四个组
    TableGroupModel *group4=[[TableGroupModel alloc]init];
    TableCellitemModel *setting=[TableCellitemModel itemWithIcon:@"MoreSetting" title:@"设置" detailTitle:@"账号未保护" vcClass:[SettingViewController class]];
    group4.items=@[setting];
    [self.datas addObject:group4];
 
}
-(void)addRunloop
{
    NSTimer *timer=[NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(getHead) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSRunLoopCommonModes]; //添加到子线程
}
-(void)getHead
{
    NSLog(@"head");
}

//街道通知的方法
-(void)changeHead:(NSNotification*)note
{
    NSData *data=[note object];
    self.userSetting.image=data;
    [self.tableView reloadData];
  
}

-(void)dealloc
{
    [Mynotification removeObserver:self];
}



@end
