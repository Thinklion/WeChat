//
//  EditViewController.h
//  微信
//
//  Created by Think_lion on 15/6/28.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>
@class EditViewController;
@protocol EditViewDelegate <NSObject>

@optional
-(void)EditingFinshed:(EditViewController*)edit indexPath:(NSIndexPath*)indexPath newInfo:(NSString*)newInfo;

@end

@interface EditViewController : UITableViewController

@property (nonatomic,copy) NSString *str;
@property (nonatomic,strong) NSIndexPath* indexPath;
@property (nonatomic,weak) id<EditViewDelegate>delegate;

@end
