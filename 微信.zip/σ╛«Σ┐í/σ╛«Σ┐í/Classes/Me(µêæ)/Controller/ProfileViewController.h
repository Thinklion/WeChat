//
//  ProfileViewController.h
//  微信
//
//  Created by Think_lion on 15/6/28.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileViewController : UITableViewController

@end
