//
//  ProfileViewController.m
//  微信
//
//  Created by Think_lion on 15/6/28.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "ProfileViewController.h"
#import "XMPPvCardTemp.h"
#import "ProfileModel.h"
#import "EditViewController.h"
#import "MyNavController.h"

@interface ProfileViewController ()<EditViewDelegate,UIActionSheetDelegate,UINavigationControllerDelegate, UIImagePickerControllerDelegate>

@property (weak, nonatomic)  UIImageView *headView;


@property (nonatomic,strong) NSMutableArray *allArr;  //里面存放的arr数组
@property (nonatomic,strong) NSMutableArray *oneArr;//里面存放第一组的用户信息
@property (nonatomic,strong) NSMutableArray *twoArr;//里面存放第二组的用户信息
@end

@implementation ProfileViewController

-(NSMutableArray *)allArr
{
    if(!_allArr){
        _allArr=[NSMutableArray array];
    }
    return _allArr;
}
-(NSMutableArray *)oneArr
{
    if(!_oneArr){
        _oneArr=[NSMutableArray array];
    }
    return _oneArr;
}
-(NSMutableArray *)twoArr
{
    if(!_twoArr){
        _twoArr=[NSMutableArray array];
    }
    return _twoArr;
}

-(instancetype)init
{
    self=[super initWithStyle:UITableViewStyleGrouped];
    if(self){
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=@"个人信息";
    self.tableView.contentInset=UIEdgeInsetsMake(15, 0, 0, 0);
    
    [self loadUserinfo];
}
//加载用户信息
-(void)loadUserinfo
{
    XmppTools *app=[XmppTools sharedxmpp];
    
    XMPPvCardTemp *temp=app.vCard.myvCardTemp;
    //1.设置头像   DefaultProfileHead_phone
    NSData *data=temp.photo?temp.photo:UIImageJPEGRepresentation([UIImage imageNamed:@"DefaultProfileHead_phone"], 1.0);
    ProfileModel *pro1=[ProfileModel profileWithImage:data name:@"头像"];
    //2.设置匿名
    NSString *nickName=temp.nickname?temp.nickname:@"未设置";
    ProfileModel *pro2=[ProfileModel profileWithInfo:nickName infoType:UserNickName name:@"昵称"];
   
    
    //3.设置微信号
    UserOperation *user=[UserOperation shareduser];
    NSString *account=user.uname;
    ProfileModel *pro3=[ProfileModel profileWithInfo:account infoType:UserWeixinNum name:@"微信号"];
    //添加到第一个数组中
    [self.oneArr addObject:pro1];
    [self.oneArr addObject:pro2];
    [self.oneArr addObject:pro3];
    [self.allArr addObject:_oneArr];
    
    //4.公司

    NSString *company=temp.orgName?temp.orgName:@"未设置";
    ProfileModel *pro4=[ProfileModel profileWithInfo:company infoType:UserCompany  name:@"公司"];
    //5.部门
    
    NSString *depart;
    if (temp.orgUnits.count > 0) {
        depart=temp.orgUnits[0];
    }
    depart=depart?depart:@"未设置";
    ProfileModel *pro5=[ProfileModel profileWithInfo:depart infoType:UserDepartment  name:@"部门"];
    //6.职位
    NSString *worker=temp.title?temp.title:@"未设置";
    ProfileModel *pro6=[ProfileModel profileWithInfo:worker infoType:UserWorker name:@"职位"];
    
    //7.电话
// myVCard.telecomsAddresses 这个get方法，没有对电子名片的xml数据进行解析
    // 使用note字段充当电话
    NSString *tel=temp.note?temp.note:@"未设置";
    ProfileModel *pro7=[ProfileModel profileWithInfo:tel infoType:UserTel name:@"电话"];
    //7.邮件
    // 用mailer充当邮件
    NSString *email=temp.mailer?temp.mailer:@"未设置";
    ProfileModel *pro8=[ProfileModel profileWithInfo:email infoType:UserEmail name:@"邮箱"];
    [self.twoArr addObject:pro4];
    [self.twoArr addObject:pro5];
    [self.twoArr addObject:pro6];
    [self.twoArr addObject:pro7];
    [self.twoArr addObject:pro8];
    [self.allArr addObject:_twoArr];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.allArr.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    NSArray *arr=self.allArr[section];
    return arr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"profileCell"];
    if(cell==nil){
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"profileCell"];
        
    }
    
    NSArray *arr=self.allArr[indexPath.section];
    ProfileModel *profile=arr[indexPath.row];
    if(profile.image){
        UIImageView *imageV=[[UIImageView alloc]initWithImage:[UIImage imageWithData:profile.image]];
        imageV.frame=CGRectMake(0, 0, 50, 50);
        cell.accessoryView=imageV;
    }
    cell.textLabel.text=profile.name;
    cell.detailTextLabel.text=profile.info;

    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

#pragma mark 设置单元格 的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *arr=self.allArr[indexPath.section];
    ProfileModel *profile=arr[indexPath.row];
    if(profile.image) {
        return 80;
    }
    return 44;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 2;
}
#pragma mark 单元格的点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *arr=self.allArr[indexPath.section];
    ProfileModel *pro=arr[indexPath.row];
    //设置头像图片
    if(pro.image){
        UIActionSheet *sheet=[[UIActionSheet alloc]initWithTitle:@"选择图片" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"拍照" otherButtonTitles:@"从手机相册中选择", nil];
        [sheet showInView:self.view];
        
        return;
    }
    //不需要设置微信号
    if(pro.infoType==UserWeixinNum) return;
    
    EditViewController *edit=[[EditViewController alloc]init];
    edit.delegate=self;
    edit.indexPath=indexPath;
    if([pro.info isEqualToString:@"未设置"]){
        edit.str=nil;
    }else{
        edit.str=pro.info;
    }
    edit.title=pro.name;
    MyNavController *nav=[[MyNavController alloc]initWithRootViewController:edit];
    [self presentViewController:nav animated:YES completion:nil];

    
}
#pragma mark actionSheet的代理方法
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex==2) return;
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    // 设置代理
    imagePicker.delegate =self;
    // 设置允许编辑
    imagePicker.allowsEditing = YES;
    // 显示图片选择器
    [self presentViewController:imagePicker animated:YES completion:nil];

    switch (buttonIndex) {
        case 0: //拍照
        {
            imagePicker.sourceType=UIImagePickerControllerSourceTypeCamera;
        }
            break;
            
        case 1: //从相册中选择
        {
            imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        }
            break;
       
    }
}
#pragma mark 图片选择完成的方法
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image=info[UIImagePickerControllerEditedImage];
    NSArray *arr=self.allArr[0];
    ProfileModel *pro=arr[0];
    pro.image=UIImageJPEGRepresentation(image, 1.0);
    //保存头像图片的方法
    [self saveHeadImage:UIImageJPEGRepresentation(image, 0.7f)];
    
    //[self.tableView reloadData];
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark 保存头像图片的方法
-(void)saveHeadImage:(NSData*)data
{
    XmppTools *app=[XmppTools sharedxmpp];
    XMPPvCardTemp *temp=app.vCard.myvCardTemp;
    temp.photo=data;
    
    NSArray *arr=self.allArr[0];
    ProfileModel *pro=arr[0];
    pro.image=data;
   
    [self.tableView reloadData];
    
    //更新 这个方法内部会实现数据上传到服务，无需程序自己操作
    [app.vCard updateMyvCardTemp:temp];  //保存头像到服务器
    
    //发送通知
    NSNotification *note=[[NSNotification alloc]initWithName:@"changeHeadIcon" object:data userInfo:nil];
    [Mynotification postNotification:note];
    
}
#pragma mark 编辑控制器的代理方法
-(void)EditingFinshed:(EditViewController *)edit indexPath:(NSIndexPath *)indexPath newInfo:(NSString *)newInfo
{
    NSArray *arr=self.allArr[indexPath.section];
    ProfileModel *pro=arr[indexPath.row];
    pro.info=newInfo; //重新设置个人信息
   
    [self addProfileModel:pro newInfo:newInfo];
    
    [self.tableView reloadData];
    
    
}


-(void)addProfileModel:(ProfileModel*)proModel newInfo:(NSString*)newInfo
{
    XmppTools *app=[XmppTools sharedxmpp];
    XMPPvCardTemp *temp=app.vCard.myvCardTemp;
     NSLog(@"电子名片  %@",temp);
    switch (proModel.infoType) {
        case UserNickName:
            temp.nickname=newInfo;
            NSLog(@"nickna,e");
            break;
        case UserWeixinNum:
            //temp.uid=newInfo;
            //不需要操作
            break;
        case UserCompany:
            temp.orgName=newInfo;
            break;
        case UserDepartment:
        {
            if(newInfo.length>0){
                temp.orgUnits=@[newInfo];
            }
        }
            break;
        case UserWorker:
            temp.title=newInfo;
            break;
        case UserTel:
            temp.note=newInfo;
            break;
        case UserEmail:
            temp.mailer=newInfo;
            break;
    }
     //更新 这个方法内部会实现数据上传到服务，无需程序自己操作
    [app.vCard updateMyvCardTemp:temp];
}


@end
