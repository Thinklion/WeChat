//
//  SettingViewController.m
//  微信
//
//  Created by Think_lion on 15/6/29.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "SettingViewController.h"
#import "SettingModel.h"
#import "SettingViewCell.h"
#import "LoginViewController.h"
#import "MyNavController.h"

@interface SettingViewController ()
@property (nonatomic,strong) NSMutableArray *allArr;

@end

@implementation SettingViewController

-(instancetype)init
{
    self=[super initWithStyle:UITableViewStyleGrouped];
    if(self){
        
    }
    return self;
}

-(NSMutableArray *)allArr
{
    if(!_allArr){
        _allArr=[NSMutableArray array];
    }
    return _allArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
   self.view.backgroundColor=WColor(236, 236, 244);
    self.tableView.contentInset=UIEdgeInsetsMake(15, 0, 5, 0);
    self.title=@"设置";
    //1.添加数组模型
    [self loadDataModel];
    
}

#pragma mark 加载数据模型
-(void)loadDataModel
{
    //1.
    SettingModel *accountAndSafe=[SettingModel settingWithTitle:@"账号与安全" detailTitle:@"未保护"];
    NSArray *oneArr=@[accountAndSafe];
    [self.allArr addObject:oneArr];
    //2.
    SettingModel *newMsg=[SettingModel settingWithTitle:@"新消息通知" detailTitle:nil];
    SettingModel *conseal=[SettingModel settingWithTitle:@"隐私" detailTitle:nil];
    SettingModel *common=[SettingModel settingWithTitle:@"通用" detailTitle:nil];
    NSArray *twoArr=@[newMsg,conseal,common];
    [self.allArr addObject:twoArr];
    //3.
     SettingModel *abount=[SettingModel settingWithTitle:@"新消息通知" detailTitle:nil];
    NSArray *threeArr=@[abount];
    [self.allArr addObject:threeArr];
    //4.
     SettingModel *loginOut=[SettingModel settingWithTitle:@"退出登录" detailTitle:nil];
    loginOut.isLoginOut=YES;
    NSArray *fourArr=@[loginOut];
    [self.allArr addObject:fourArr];
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return self.allArr.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSArray *arr=self.allArr[section];
    return arr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SettingViewCell *cell=[SettingViewCell cellWithTableView:tableView indentifier:@"settingCell"];
    NSArray *arr=self.allArr[indexPath.section];
    SettingModel *model=arr[indexPath.row];
    cell.settingModel=model;
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 2;
}
#pragma mark 单元格的点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *arr=self.allArr[indexPath.section];
    SettingModel *model=arr[indexPath.row];
    //退出登录操作
    if(model.isLoginOut){
        XmppTools *app=[XmppTools sharedxmpp];
        [app xmppLoginOut]; //退出
        //跳转到登录窗口
        LoginViewController *login=[[LoginViewController alloc]init];
        MyNavController *nav=[[MyNavController alloc]initWithRootViewController:login];
        [self dismissViewControllerAnimated:NO completion:nil];
        [UIApplication sharedApplication].keyWindow.rootViewController=nav;
        
        }
    return;
}



@end
