//
//  SettingModel.h
//  微信
//
//  Created by Think_lion on 15/6/29.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SettingModel : NSObject

@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *detailTitle;
@property (nonatomic,assign) BOOL isLoginOut;  //默认是no

+(instancetype)settingWithTitle:(NSString*)title detailTitle:(NSString*)detailTitle;

@end
