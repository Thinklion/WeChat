//
//  SettingModel.m
//  微信
//
//  Created by Think_lion on 15/6/29.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "SettingModel.h"

@implementation SettingModel

+(instancetype)settingWithTitle:(NSString *)title detailTitle:(NSString *)detailTitle
{
    SettingModel *setting=[[SettingModel alloc]init];
    setting.title=title;
    setting.detailTitle=detailTitle;
    return setting;
}

@end
