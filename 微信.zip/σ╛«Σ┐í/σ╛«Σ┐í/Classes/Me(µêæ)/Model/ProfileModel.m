//
//  ProfileModel.m
//  微信
//
//  Created by Think_lion on 15/6/28.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "ProfileModel.h"

@implementation ProfileModel


+(instancetype)profileWithInfo:(NSString *)info infoType:(UserInfoType)infoType  name:(NSString *)name
{
    ProfileModel *pro=[[ProfileModel alloc]init];
    pro.info=info;
    pro.name=name;
    pro.infoType=infoType;
    return pro;
}

+(instancetype)profileWithImage:(NSData *)image name:(NSString *)name
{
    ProfileModel *pro=[[ProfileModel alloc]init];
    pro.name=name;
    pro.image=image;
    return pro;
}

@end
