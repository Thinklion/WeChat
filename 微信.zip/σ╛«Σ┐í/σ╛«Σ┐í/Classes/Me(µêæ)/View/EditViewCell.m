//
//  EditViewCell.m
//  微信
//
//  Created by Think_lion on 15/6/28.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "EditViewCell.h"
#import "EditView.h"

@interface EditViewCell ()
@property (nonatomic,weak) EditView *editView;
@end

@implementation EditViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self){
        [self setupFirst];
    }
    return self;
}
-(void)setupFirst
{
    EditView *editView=[[EditView alloc]initWithFrame:self.bounds];
    [self.contentView addSubview:editView];
    self.editView=editView;
    self.input=editView.textField;
}

+(instancetype)cellWithTableView:(UITableView *)table indentifier:(NSString *)indentifier
{
    EditViewCell *cell=[table dequeueReusableCellWithIdentifier:indentifier];
    if(cell==nil){
        cell=[[EditViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentifier];
    }
    return cell;
}

-(void)setStr:(NSString *)str
{
    _str=[str copy];
    self.editView.str=str;
}

@end
