//
//  SettingViewCell.m
//  微信
//
//  Created by Think_lion on 15/6/29.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "SettingViewCell.h"

#import "SettingModel.h"
#import "SettingView.h"


@interface SettingViewCell ()
@property (nonatomic,weak) SettingView *settingView;
@end

@implementation SettingViewCell


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self){
        [self setupFirst];
    }
    return self;
}
//添加子视图
-(void)setupFirst
{
    SettingView *setting=[[SettingView alloc]initWithFrame:self.bounds];
    
    [self.contentView addSubview:setting];
    self.settingView=setting;
}
-(void)setSettingModel:(SettingModel *)settingModel
{
    _settingModel=settingModel;
    self.settingView.settingModel=settingModel;
}
//实例化标示图单元
+(instancetype)cellWithTableView:(UITableView *)table indentifier:(NSString *)indentifier
{
    SettingViewCell *cell=[table dequeueReusableCellWithIdentifier:indentifier];
    if(cell==nil){
        cell=[[SettingViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentifier];
    }
    return cell;
}

@end
