//
//  EditView.h
//  微信
//
//  Created by Think_lion on 15/6/28.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MyTextField;
@interface EditView : UIView

@property (nonatomic,copy) NSString *str;
@property (nonatomic,weak) MyTextField *textField;
@end
