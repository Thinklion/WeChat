//
//  EditView.m
//  微信
//
//  Created by Think_lion on 15/6/28.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "EditView.h"
#import "MyTextField.h"

@interface EditView ()

@end

@implementation EditView

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self){
        //1.添加姿势图
        [self addEditInput];
    }
    return self;
}

-(void)addEditInput
{
    MyTextField *input=[[MyTextField alloc]init];
    input.x=10;
    input.y=0;
    input.width=ScreenWidth-20;
    input.height=self.height;

    [self addSubview:input];
    input.text=self.str;
    input.font=MyFont(17);
    self.textField=input;
}
-(void)setStr:(NSString *)str
{
    self.textField.text=str;
}

@end
