//
//  EditViewCell.h
//  微信
//
//  Created by Think_lion on 15/6/28.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MyTextField ;

@interface EditViewCell : UITableViewCell

@property (nonatomic,weak) MyTextField *input;
@property (nonatomic,copy) NSString *str;

+(instancetype)cellWithTableView:(UITableView*)table indentifier:(NSString*)indentifier;

@end
