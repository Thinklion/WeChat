//
//  AddFriendController.h
//  微信
//
//  Created by Think_lion on 15/7/4.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddFriendController : UITableViewController

@end
