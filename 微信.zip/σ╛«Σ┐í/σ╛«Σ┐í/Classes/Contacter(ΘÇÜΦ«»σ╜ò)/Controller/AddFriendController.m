//
//  AddFriendController.m
//  微信
//
//  Created by Think_lion on 15/7/4.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "AddFriendController.h"
#import "AddFriendCell.h"
#import "MyTextField.h"

@interface AddFriendController ()<UITextFieldDelegate>
@property (nonatomic,weak) MyTextField *myText;
@end

@implementation AddFriendController

-(instancetype)init
{
    self=[super initWithStyle:UITableViewStyleGrouped];
    if(self){
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //右边导航栏按钮
    [self addRightBtn];
}

-(void)addRightBtn
{
    UIButton *btn=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30, 40)];
    btn.titleEdgeInsets=UIEdgeInsetsMake(0, 10, 0, -10);
    btn.titleLabel.font=MyFont(15);
    [btn setTitle:@"添加" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(addFriend) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithCustomView:btn ];
}

#pragma mark 添加朋友的方法
-(void)addFriend
{
    NSString *uname=[self trimStr:self.myText.text];
    uname=[uname lowercaseString];  //转成小写
    if([uname isEqualToString:@""]) return;
    
    //添加好友
    
//    XmppTools *app=[XmppTools sharedxmpp];
//    XMPPJID *jid=[XMPPJID jidWithUser:uname domain:ServerName resource:nil];
//    //判断时代否为自己
//    UserOperation *user=[UserOperation shareduser];
//    NSString *me=user.uname;
//    if([me isEqualToString:uname]){
//        [self showMessage:@"不能添加自己为好友"];
//        return;
//    }
//    //判断是否子已经存在的好友
//    if([app.rosterStorage userExistsWithJID:jid xmppStream:app.xmppStream]){
//        [self showMessage:@"此用户已经是你的好友了"];
//        return;
//    }
//    
//    
//    [app.roster subscribePresenceToUser:jid];
    
    [BaseMethod showError:@"sorry,此模块正在开发中..."];

}

-(void)showMessage:(NSString *)msg
{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"温馨提示" message:msg delegate:nil cancelButtonTitle:@"好的" otherButtonTitles:nil, nil];
    [alert show];
}





- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    AddFriendCell *cell=[AddFriendCell cellWithTableView:tableView indentifier:@"addFriend"];
    
    self.myText=cell.mytextField;
    self.myText.delegate=self;
    return cell;
}


-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}



#pragma mark 去掉两边空格的方法
-(NSString*)trimStr:(NSString*)str
{
    str=[str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    return str;
}
#pragma mark 滚动视图停止编辑
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}
@end
