//
//  ContacterController.m
//  微信
//
//  Created by Think_lion on 15-6-14.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "ContacterController.h"
#import "UIBarButtonItem+CH.h"
#import "XmppTools.h"
#import "ContacterModel.h"
#import "ContacterCell.h"
#import "ChatController.h"
#import "NewFriendController.h"
#import "ChatTogetherController.h"
#import "AddFriendController.h"


@interface ContacterController ()<NSFetchedResultsControllerDelegate,UISearchBarDelegate,UIAlertViewDelegate>

@property (nonatomic,strong) NSFetchedResultsController *resultsContrl;

@property (nonatomic,strong) NSMutableArray *keys ;//存放所有标示图分区的键
//定义一个字典的集合  用来存贮联系人名字拼音的首字母相同的人   一个键可以对应多个值
@property (strong,nonatomic)NSMutableDictionary *data;
//定义好友的键
@property (nonatomic,strong) NSMutableArray *otherKey;
//定义一个判断值 (好友列表在程序开启的时候只从网上加载一次)
@property (nonatomic,assign) BOOL isLoad;
//删除好友时用到的NSIndexPath
@property (nonatomic,strong) NSIndexPath *indexPath;
@end

@implementation ContacterController

-(NSMutableArray *)keys
{
    if(_keys==nil) {
        _keys=[NSMutableArray array];
    }
    return _keys;
}
-(NSMutableDictionary *)data
{
    if(_data==nil){
        _data=[NSMutableDictionary dictionary];
    }
    return _data;
}

-(NSMutableArray *)otherKey
{
    if(_otherKey==nil){
        _otherKey=[NSMutableArray array];
    }
    return _otherKey;
}


-(instancetype)init
{
    self=[super initWithStyle:UITableViewStyleGrouped];
    if(self){
       
    }
    return self;
}
#pragma mark view完成加载
- (void)viewDidLoad {
    [super viewDidLoad];
    //添加标签
    [self setupFriendLabel];
    //背景颜色  236 236 244   选中颜色208 208 208
    self.view.backgroundColor=WColor(236, 236, 244);
    //self.tableView.contentInset=UIEdgeInsetsMake(10, 0, 5, 0);
   // self.currentIndex=1;
    //设置索引文本的颜色
    self.tableView.sectionIndexColor=[UIColor grayColor];
    self.tableView.sectionIndexBackgroundColor=[UIColor clearColor];
        //1.添加右侧导航栏上面的的按钮
    [self setupRightButtun];
    //2.添加搜搜兰
    [self setupSearchBar];
    //3.获得好友数据
    [self getFriendData];
   
    
   
}
#pragma mark 获得好朋友
-(void)getFriendData
{

     XmppTools *xmpp=[XmppTools sharedxmpp];
    //1.上下文   XMPPRoster.xcdatamodel
    NSManagedObjectContext *context=xmpp.rosterStorage.mainThreadManagedObjectContext;
    
    //2.Fetch请求
    NSFetchRequest *fetch=[NSFetchRequest fetchRequestWithEntityName:@"XMPPUserCoreDataStorageObject"];
    //3.排序和过滤
//    NSPredicate *pre=[NSPredicate predicateWithFormat:@"streamBareJidStr =%@",xmpp.jid];
//    fetch.predicate=pre;
//    
    NSSortDescriptor *sort=[NSSortDescriptor sortDescriptorWithKey:@"displayName" ascending:YES];
    fetch.sortDescriptors=@[sort];
  
    //4.执行查询获取数据
    _resultsContrl=[[NSFetchedResultsController alloc]initWithFetchRequest:fetch managedObjectContext:context sectionNameKeyPath:nil cacheName:nil];
    _resultsContrl.delegate=self;
    //执行
    NSError *error=nil;
    [_resultsContrl performFetch:&error];
    if(error){
        NSLog(@"出现错误%@",error);
    }
    //如果数组里面有值才调用这个方法
    if(_resultsContrl.fetchedObjects.count){
         [self devideFriend];
          self.isLoad=YES;
    }
   
   
}
#pragma mark 朋友分区 （在NSFetchRequest里面调用这个方法）
-(void)devideFriend
{
    XmppTools *app=[XmppTools sharedxmpp];
    //获得好友的列表
    for(XMPPUserCoreDataStorageObject *user in _resultsContrl.fetchedObjects){
  
        ContacterModel *friend=[[ContacterModel alloc]init];
        friend.jid=user.jid;
        friend.tidStr=[self cutStr:user.jidStr];
        //获得好友的头像
        if(user.photo){
            friend.headIcon=user.photo;
        }else{
            friend.headIcon=[UIImage imageWithData: [app.avatar photoDataForJID:user.jid]];
        }
        NSData *data= [app.avatar photoDataForJID:user.jid];
        friend.nickName=user.nickname;
       // NSLog(@" %@   朋友头像%@",user.jid,data);
        friend.vcClass=[ChatController class];
    
        //把用户名转成拼音
        friend.py=[self hanziZpinyin:friend.nickName];
        //取出拼音首字母
        NSString *firstName=[friend.py substringToIndex:1];
        firstName=[firstName uppercaseString]; //转成大写
        
        //获得key所对应的数据(数组)
        NSArray *arr=[self.data objectForKey:firstName];
        NSMutableArray *contacter; //临时数据
        //如果没有值
        if(arr==nil){
            contacter=[NSMutableArray arrayWithObject:friend];
        }else{
            contacter=[NSMutableArray arrayWithArray:arr];
            [contacter addObject:friend];
        }
        //设置字典的键和值
        [self.data setObject:contacter forKey:firstName];
     
    }
    //获得所有的键
    NSArray *key=[self.data allKeys];
    //NSMutableArray *newKey=[];
    for(NSString *str in key){
        if(![str isEqualToString:@"🔍"]){
            [self.otherKey addObject:str];
        }
    }
  
    NSArray *k=[self.otherKey sortedArrayUsingSelector:@selector(compare:)];
    
    [self.keys addObjectsFromArray:k];


}
#pragma mark 添加朋友标签
-(void)setupFriendLabel
{
    //由于这个是固定的cell所以就自定义模型数据就行了
    ContacterModel *c1=[[ContacterModel alloc]init];
    c1.tidStr=@"新的朋友";
    c1.headIcon=[UIImage imageNamed:@"plugins_FriendNotify"];
    c1.vcClass=[NewFriendController class];
    ContacterModel *c2=[[ContacterModel alloc]init];
    c2.headIcon=[UIImage imageNamed:@"add_friend_icon_addgroup"];
    c2.tidStr=@"群聊";
    c2.vcClass=[ChatTogetherController class];
    ContacterModel *c3=[[ContacterModel alloc]init];
    c3.headIcon=[UIImage imageNamed:@"Contact_icon_ContactTag"];
    c3.tidStr=@"标签";
    c3.vcClass=[ChatTogetherController class];

   
    
    NSMutableArray *arr=[NSMutableArray array];
    [arr addObject:c1];
    [arr addObject:c2];
    [arr addObject:c3];
    [self.data setObject:arr forKey:@"🔍"];
    //添加件到数组中
    [self.keys addObject:@"🔍"];
  
}
#pragma mark 添加搜索栏
-(void)setupSearchBar
{
    UISearchBar *search=[[UISearchBar alloc]init];
    CGFloat searchX=5;
    search.frame=CGRectMake(10, 5, ScreenWidth-20, 25);
    search.barStyle=UIBarStyleDefault;
    search.backgroundColor=[UIColor whiteColor];
    
    //实例化一个搜索栏
    //取消首字母吧大写
    search.autocapitalizationType=UITextAutocapitalizationTypeNone;
    search.autocorrectionType=UITextAutocorrectionTypeNo;
    //代理
    search.placeholder=@"搜索";
    search.layer.borderWidth=0;
    
    UIView *searchV=[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 35)];
    searchV.backgroundColor=WColorAlpha(189, 189, 195, 0.7);
    [searchV addSubview:search];
    // search.delegate=self;
    
    
    self.tableView.tableHeaderView=searchV;
    

}

#pragma mark
-(void)setupRightButtun
{
    self.navigationItem.rightBarButtonItem=[UIBarButtonItem itemWithIcon:@"contacts_add_friend" highIcon:nil target:self action:@selector(rightClick)];
}
#pragma mark 右上角按钮添加好朋友的方法
-(void)rightClick
{
    AddFriendController *add=[[AddFriendController alloc]init];
    add.title=@"添加朋友";
    [self.navigationController pushViewController:add animated:YES];
    
}
#pragma mark 当请求好友的数据发生改变的时候调用这个方法
-(void)controllerDidChangeContent:(NSFetchedResultsController *)controller
{
    NSLog(@"数据发生改变了  contacer");
 
    if(!self.isLoad){
        //1.把好友按组分区
        [self devideFriend];
          self.isLoad=YES;
    }
    
    [self.tableView reloadData];
}

#pragma mark - 返回有多少个区
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return self.keys.count;
}
#pragma mark 返回有多少个行
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    
    NSString *key=self.keys[section];
    NSArray *arr=[self.data objectForKey:key];
    return arr.count;
}
#pragma mark 设置每个区的标题
-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    //如果是第一个区 不返回
    if(section==0){
        return nil;
    }
    NSString *title=self.keys[section];
    return title;
}
#pragma mark 表单元的设置
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    ContacterCell *cell=[ContacterCell cellWithTableView:tableView indentifier:@"friendCell"];

    NSString *key=self.keys[indexPath.section];
    NSArray *arr=[self.data objectForKey:key];
    ContacterModel *contacter=arr[indexPath.row];
    //传递模型
    cell.contacerModel=contacter;

    return cell;
}

#pragma mark 选中单元格的事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *key=self.keys[indexPath.section];
    NSArray *arr=[self.data objectForKey:key];
    
    ContacterModel *contacter=arr[indexPath.row];

    UIViewController *vc=[[contacter.vcClass alloc]init];
    vc.title=contacter.tidStr;
      //如果是聊天控制器
    if([vc isKindOfClass:[ChatController class]]){
        
        ChatController  *chat=(ChatController*)vc;
        chat.jid=contacter.jid;
        chat.photo=contacter.headIcon;  //传递头像
        [self.navigationController pushViewController:chat animated:YES];
        return ;
    }
    
    [self.navigationController pushViewController:vc animated:YES];
    
}

#pragma mark 返回分区头的高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    //如果是第一个区
    if(section==0){
        return 0;
    }
    return 10;
}
#pragma mark 返回标示图的索引
-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
   return self.keys;
}
#pragma mark 滑动删除单元格
-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}
#pragma mark 改变删除单元格按钮的文字
-(NSString*)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}
#pragma mark 单元格删除的点击事件
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    //当点击删除按钮的时候执行
    if(editingStyle==UITableViewCellEditingStyleDelete){
        //赋值indexPath
        self.indexPath=indexPath;
        //弹出提醒框
        [self alert];
        
    }
}
#pragma mark 弹出视图
-(void)alert
{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"友情提示" message:@"你确定要删除此好友吗?" delegate:self cancelButtonTitle:@"删除" otherButtonTitles:@"取消", nil];
    [alert show];
}
#pragma mark alertView的代理方法
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    //如果等于1就是取消
    if(buttonIndex==1) return;
    //等于0就是删除
    if(buttonIndex==0){
        NSString *key=self.keys[_indexPath.section];
        NSMutableArray *arr=[self.data objectForKey:key];
        ContacterModel *friend=arr[_indexPath.row];
        NSString *uname=friend.tidStr;
        
//       //同一个键名下面的好友小于等于1才删除键
        if(arr.count<=1){
            [self.keys removeObjectAtIndex:_indexPath.section];
        }
        //删除模型
        [arr removeObjectAtIndex:_indexPath.row];
        
        XmppTools *app=[XmppTools sharedxmpp];
        [app.roster removeUser:friend.jid]; //删除好友
//
        //清除首页的模型(通知方式)
        NSNotification *note=[[NSNotification alloc]initWithName:DeleteFriend object:uname userInfo:nil];
        [Mynotification postNotification:note];
        
        [self.tableView reloadData];
    }
}

#pragma mark reloadData
-(void)reloadData
{
    [self.tableView reloadData];
}
#pragma  mark 去掉@符号
-(NSString*)cutStr:(NSString*)str
{
    NSArray *arr=[str componentsSeparatedByString:@"@"];
    return arr[0];
}
#pragma mark 把汉字转成把拼音
-(NSString *)hanziZpinyin:(NSString*)str{
    NSMutableString *ms = [[NSMutableString alloc] initWithString:str];
    if (CFStringTransform((__bridge CFMutableStringRef)ms, 0, kCFStringTransformMandarinLatin, NO)) {
       // NSLog(@"Pingying: %@", ms); // wǒ shì zhōng guó rén
    }
    if (CFStringTransform((__bridge CFMutableStringRef)ms, 0, kCFStringTransformStripDiacritics, NO)) {
       // NSLog(@"Pingying: %@", ms); // wo shi zhong guo ren
    }
    return ms;
}

#pragma mark 滚动视图停止编辑
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}

@end
