//
//  AddFriendCell.h
//  微信
//
//  Created by Think_lion on 15/7/4.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MyTextField;
@interface AddFriendCell : UITableViewCell

@property (nonatomic,weak) MyTextField* mytextField;
+(instancetype)cellWithTableView:(UITableView*)tableView indentifier:(NSString*)indentifier;

@end
