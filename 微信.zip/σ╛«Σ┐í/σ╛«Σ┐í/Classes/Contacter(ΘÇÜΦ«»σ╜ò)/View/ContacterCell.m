//
//  ContacterCell.m
//  微信
//
//  Created by Think_lion on 15/6/18.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "ContacterCell.h"
#import "ContacterView.h"

@interface ContacterCell ()
@property (nonatomic,weak) ContacterView *cView;

@end


@implementation ContacterCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self){
        //添加子控件
        [self adChildView];
    }
    return self;
}

//设置模型数据
-(void)setContacerModel:(ContacterModel *)contacerModel
{
   // _contacerModel=contacerModel;
    self.cView.contacterModel=contacerModel;
    
}
#pragma mark 初始化单元格
+(instancetype)cellWithTableView:(UITableView *)tableView indentifier:(NSString *)indentifier
{
    ContacterCell *cell=[tableView dequeueReusableCellWithIdentifier:indentifier];
    if(cell==nil){
        cell=[[ContacterCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentifier];
    }
    
    return cell;
}

-(void)adChildView
{
    ContacterView *cView=[[ContacterView alloc]init];
    cView.frame=self.bounds;
    [self.contentView addSubview:cView];
    self.cView=cView;
}

@end
