//
//  AddFriendView.m
//  微信
//
//  Created by Think_lion on 15/7/4.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "AddFriendView.h"
#import "MyTextField.h"
#define marginLeft 20

@implementation AddFriendView

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self){
        [self addSearchBar];
        
    }
    return self;
}

-(void )addSearchBar
{
    MyTextField *myText=[[MyTextField alloc]init];
   // myText.returnKeyType=UIReturnKeySearch; //发送按钮
    myText.font=MyFont(16);
    //设置键盘自动判断有没有文本的属性
    //myText.enablesReturnKeyAutomatically=YES;
    myText.image=@"add_friend_icon_search";
    myText.constomPlaceholder=@"微信号/手机号";
    myText.height=30;
    myText.x=marginLeft;
    myText.width=ScreenWidth-marginLeft*2;
    myText.y=(self.height-myText.height)*0.5;
    
    [self addSubview:myText];
    self.mytextField=myText ;
    
}

@end
