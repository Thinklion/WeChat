//
//  ContacterView.m
//  微信
//
//  Created by Think_lion on 15/6/18.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "ContacterView.h"
#import "ContacterModel.h"

#define headWidth  30
#define headHeight  headWidth
#define marginLeft 10

@interface ContacterView ()

@property (nonatomic,weak) UIImageView *head;
@property (nonatomic,weak) UILabel *name;

@end

@implementation ContacterView

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self){
       //1、添加子控件
        [self addChild];
        //2.添加用户名
        
    }
    return self;
}
-(void)addChild
{
    //1.添加头像
    UIImageView *head=[[UIImageView alloc]init];
    CGFloat headY=7;
    head.frame=CGRectMake(marginLeft, headY, headWidth, headHeight);
    [self addSubview:head];
    self.head=head;
    //2.添加用户名
    UILabel *name=[[UILabel alloc]init];
    name.font=MyFont(17);
    CGFloat nameX=CGRectGetMaxX(head.frame)+marginLeft;
    name.textColor=[UIColor blackColor];
    name.frame=CGRectMake(nameX, 7, 250, headHeight);
    [self addSubview:name];
    self.name=name;
    
}
-(void)setContacterModel:(ContacterModel *)contacterModel
{
    self.head.image=contacterModel.headIcon?contacterModel.headIcon:[UIImage imageNamed:@"DefaultProfileHead_phone"];
    if(contacterModel.nickName){
        self.name.text=contacterModel.nickName;
    }else{
        self.name.text=contacterModel.tidStr;
    }
   
   
}

@end
