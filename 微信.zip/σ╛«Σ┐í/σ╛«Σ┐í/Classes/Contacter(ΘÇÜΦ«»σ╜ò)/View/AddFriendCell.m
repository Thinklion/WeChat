//
//  AddFriendCell.m
//  微信
//
//  Created by Think_lion on 15/7/4.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "AddFriendCell.h"
#import "AddFriendView.h"
#import "MyTextField.h"

@implementation AddFriendCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self){
        //添加子控件
        [self adChildView];
    }
    return self;
}
-(void)adChildView
{
    AddFriendView *add=[[AddFriendView alloc]initWithFrame:self.bounds];
    self.mytextField=add.mytextField;
    [self.contentView addSubview:add];
}

#pragma mark 初始化单元格
+(instancetype)cellWithTableView:(UITableView *)tableView indentifier:(NSString *)indentifier
{
    AddFriendCell *cell=[tableView dequeueReusableCellWithIdentifier:indentifier];
    if(cell==nil){
        cell=[[AddFriendCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentifier];
    }
    
    return cell;
}

@end
