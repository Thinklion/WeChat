//
//  ContacterModel.m
//  微信
//
//  Created by Think_lion on 15/6/17.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "ContacterModel.h"

@implementation ContacterModel

@end
