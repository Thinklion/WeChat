//
//  RegisterController.m
//  微信
//
//  Created by Think_lion on 15/6/16.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//
#import "MyTextField.h"
#import "RegisterController.h"
#import "MyTabBarController.h"

#define commonMargin 20
#define marginX 20
#define textFieldWidth  (ScreenWidth-2*marginX)
#define textFieldHeight 30

@interface RegisterController ()<UITextFieldDelegate>
@property (nonatomic,weak) UIButton *regisBtn;
@property (nonatomic,weak) MyTextField *username;
@property (nonatomic,weak) MyTextField *pass;
@end

@implementation RegisterController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=@"注册";
    self.view.backgroundColor=[UIColor whiteColor];
    //1.添加子控件
    [self setupChild];
    //2.添加手势识别器
    [self addGesture];
}
#pragma mark 添加手势识别器
-(void)addGesture
{
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapClick:)];
    tap.numberOfTapsRequired=1;
    [self.view addGestureRecognizer:tap];
}
#pragma mark 点击的方法
-(void)tapClick:(id)sender
{
    [self.view endEditing:YES];
}
- (void)setupChild {
    //1.添加输入用户名的框
    MyTextField *username=[[MyTextField alloc]init];
    username.delegate=self;
    username.frame=CGRectMake(marginX, commonMargin, textFieldWidth, textFieldHeight);
    username.image=@"biz_pc_main_info_profile_login_user_icon";
    username.constomPlaceholder=@"请输入用户名/手机号";
    [self.view addSubview:username];
    self.username=username;
    //2.添加下划线
    CGFloat oneLineY=commonMargin+textFieldHeight+10;
    [self addbottomLineWith:CGRectMake(marginX, oneLineY, textFieldWidth, 0.5)];
    //3.添加密码输入框
    MyTextField *pass=[[MyTextField alloc]init];
    pass.delegate=self;
    pass.secureTextEntry=YES;
    CGFloat passY=commonMargin+textFieldHeight+20;
    pass.frame=CGRectMake(marginX, passY, textFieldWidth, textFieldHeight);
    pass.image=@"biz_pc_main_info_profile_login_pw_icon";
    pass.constomPlaceholder=@"请输入密码";
    [self.view addSubview:pass];
    self.pass=pass;
    //4.添加下划线
    CGFloat twoLineY=passY+textFieldHeight+10;
    [self addbottomLineWith:CGRectMake(marginX, twoLineY, textFieldWidth, 0.5)];
    //5.添加注册按钮
    CGFloat regisbtnY=twoLineY+20;
    [self addRegisButton:CGRectMake(marginX, regisbtnY, textFieldWidth, 40)];
  
    
}
#pragma mark 添加下划线的方法
-(void)addbottomLineWith:(CGRect)bounds
{
    UIImageView *line=[[UIImageView alloc]initWithFrame:bounds];
    //line.width=0.5;
    line.backgroundColor=[UIColor lightGrayColor];
    [self.view addSubview:line];
}
#pragma mark 添加登陆按钮
-(void)addRegisButton:(CGRect)bounds
{
    UIButton *btn=[[UIButton alloc]initWithFrame:bounds];
    self.regisBtn=btn;
    btn.enabled=NO;
    
    //PayCardLightGreenBG   fts_green_btn
    [btn setBackgroundImage:[UIImage resizedImage:@"fts_green_btn"] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage resizedImage:@"fts_green_btn_HL"] forState:UIControlStateHighlighted];
    [btn setBackgroundImage:[UIImage resizedImage:@"GreenBigBtnDisable"] forState:UIControlStateDisabled];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn setTitleColor:WColorAlpha(255, 255, 255, 0.5) forState:UIControlStateDisabled];
    [btn setTitle:@"注册" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(regisClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if(self.username.text.length!=0 && self.pass.text.length!=0){
        self.regisBtn.enabled=YES;
    }
    // NSLog(@"%@  %zd",textField.text,textField.text.length);
    if(textField.text.length<=1){
        self.regisBtn.enabled=NO;
    }
    
    return YES;
}

#pragma mark 注册按钮点击方法
-(void)regisClick
{
    NSString *uname=[self trim:self.username.text];
    NSString *pass=[self trim:self.pass.text];
    //登陆的方法
    UserOperation *user=[UserOperation shareduser];
    user.uname=uname;
    user.password=pass;
    XmppTools *app=[XmppTools sharedxmpp];
    app.registerOperation=YES;  //注册的方法
    //把block转成弱应用
    __weak typeof(self) selfVc=self;
    // __weak typeof(self) selfVc=self;
    //显示旋转矿
    [BaseMethod showMessage:@"注册中..." toView:self.view];
    [self.view endEditing:YES];
    [app regist:^(XMPPResultType xmppType) {
        [self handle:xmppType];
    }];

}
#pragma mark 用户登录验证的方法
-(void)handle:(XMPPResultType)xmppType
{
    //回到主线程
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [BaseMethod hideFormView:self.view];
        switch (xmppType) {
            case XMPPResultRegisterSuccess:
            {
                [BaseMethod showSuccess:@"恭喜您,注册成功" toView:self.view];
                [self enterHome];
            }
                break;
            case XMPPResultRegisterFailture:
            {
                [BaseMethod showError:@"抱歉,注册失败,请重试..." toView:self.view];
            }
                break;
            case XMPPResultNetworkErr:
            {
                [BaseMethod showError:@"网络异常" toView:self.view];
            }
                break;
        }
    });
    
}
#pragma mark 登录成功后进入主界面
-(void)enterHome
{
    UserOperation *user=[UserOperation shareduser];
    user.loginStatus=YES; //登录成功保存登录状态
    
    [self dismissViewControllerAnimated:NO completion:nil];
    
    MyTabBarController *tab=[[MyTabBarController alloc]init];
    [self presentViewController:tab animated:NO completion:nil];
    
    
}

#pragma mark 截取字符串空格的方法
-(NSString*)trim:(NSString*)str
{
    str=[str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    return [str lowercaseString];
}

-(void)dealloc
{
    NSLog(@"登录控制器消失了");
}

@end
