//
//  MyTextField.m
//  新闻
//
//  Created by Think_lion on 15/5/8.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "MyTextField.h"

@interface MyTextField ()
@property (nonatomic,weak) UIImageView *img;

@end

@implementation MyTextField

-(instancetype)init
{
    self=[super init];
    if(self){
       
        self.font=[UIFont systemFontOfSize:13]; //设置字体
        //self.clearButtonMode=UITextFieldViewModeAlways; //
       // self.backgroundColor=[UIColor orangeColor];
        
    }
    return self;
}

-(void)setConstomPlaceholder:(NSString *)constomPlaceholder
{
    NSMutableDictionary *dict=[NSMutableDictionary dictionary];
    dict[NSForegroundColorAttributeName]=[UIColor grayColor];
    self.attributedPlaceholder=[[NSAttributedString alloc]initWithString:constomPlaceholder attributes:dict];
    
}
-(void)setImage:(NSString *)image
{
    UIImageView *img=[[UIImageView alloc]init];
    img.frame=CGRectMake(0, 10, 30, 30);
    img.image=[UIImage imageNamed:image];
    self.leftViewMode=UITextFieldViewModeAlways; //总是显示
    self.leftView=img;
    self.img=img;
}
-(CGRect)leftViewRectForBounds:(CGRect)bounds
{
    return CGRectMake(10, 10, 30, 0);
    
    return bounds;
}


-(void)layoutSubviews
{
    [super layoutSubviews];
    self.img.frame=CGRectMake(0, 0, 30, 30);
}

@end
