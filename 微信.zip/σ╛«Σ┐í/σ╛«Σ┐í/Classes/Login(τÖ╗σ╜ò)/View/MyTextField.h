//
//  MyTextField.h
//  新闻
//
//  Created by Think_lion on 15/5/8.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTextField : UITextField

@property (nonatomic,copy) NSString *image;
@property (nonatomic,copy) NSString *constomPlaceholder;


@end
