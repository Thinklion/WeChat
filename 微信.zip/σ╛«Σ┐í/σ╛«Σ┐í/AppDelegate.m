//
//  AppDelegate.m
//  微信
//
//  Created by Think_lion on 15-6-3.
//  Copyright (c) 2015年 Think_lion. All rights reserved.
//

#import "AppDelegate.h"
#import "XMPPFramework.h"
#import "MyTabBarController.h"
#import "MyNavController.h"
#import "LoginViewController.h"


@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    //
    self.window=[[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor=[UIColor whiteColor];
    [self.window makeKeyAndVisible];  //设置主窗口 并可见
    //通过这个方法决定跳转到那个视图
    [UserOperation loginByStatus];

    
    float sysVersion=[[UIDevice currentDevice]systemVersion].floatValue;
    if (sysVersion>=8.0) {
        
        UIUserNotificationType type=UIUserNotificationTypeAlert | UIUserNotificationTypeBadge | UIUserNotificationTypeSound;
        UIUserNotificationSettings *settings=[UIUserNotificationSettings settingsForTypes:type categories:nil];
        [[UIApplication sharedApplication]registerUserNotificationSettings:settings];
    }

  
    
    return YES;
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    //后台开启任务时让程序保持运行状态（运行时间不确定）
    [application beginBackgroundTaskWithExpirationHandler:^{
        
    }];
}




@end
